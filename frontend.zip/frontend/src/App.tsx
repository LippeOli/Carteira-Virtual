import { Button } from "@/components/ui/button"

export default function App() {
  return (
    
    <Button>Click me</Button>
    
  )
}
